# Imagery

![Imagery](./imagery.png?raw=true "Imagery")

To try Imagery app create a CloudFormation stack based on the template https://s3.amazonaws.com/awsinaction/chapter13/template.json
