# Node Control Center for AWS

![Node Control Center for AWS](./nodecc.png?raw=true "Node Control Center for AWS")

Install the dependencies ...

	npm install

... and run nodecc

	node index.js
